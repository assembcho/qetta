# Terraform Skeleton
Add modules for RDS(PostgreSQL), Redis, S3, K8s cluster. Use OIDC+Vault/KMS for secrets.
