Helm charts skeleton for api/risk/dashboard.
