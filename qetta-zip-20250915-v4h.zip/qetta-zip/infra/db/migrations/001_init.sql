-- Qetta DB schema init (PostgreSQL 15)
create extension if not exists pgcrypto;

create table if not exists tenants(
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz default now()
);

create table if not exists merchants(
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references tenants(id),
  name text not null,
  risk_band text check (risk_band in ('A','B','C')) default 'B',
  t0_enabled boolean default false,
  daily_t0_cap_bigint bigint default 0,
  created_at timestamptz default now()
);

create table if not exists payments(
  id text primary key,
  tenant_id uuid references tenants(id),
  merchant_id uuid references merchants(id),
  amount bigint not null,
  currency text not null,
  created_at timestamptz not null,
  raw jsonb not null,
  idempotency_key text unique
);

create table if not exists risk_decisions(
  order_id text primary key references payments(id),
  risk numeric not null,
  mode text not null check (mode in ('T0','T1','TN','MANUAL')),
  holdback numeric not null,
  reasons text[] not null,
  policy_hash text not null,
  model_hash text not null,
  decided_at timestamptz default now()
);

create table if not exists accounts(
  id bigserial primary key,
  tenant_id uuid references tenants(id),
  code text not null,
  name text not null,
  type text not null check (type in ('ASSET','LIAB','EQUITY','INCOME','EXPENSE')),
  currency text not null
);
create unique index if not exists ux_accounts_tenant_code on accounts(tenant_id, code);

create table if not exists journals(
  id bigserial primary key,
  tenant_id uuid references tenants(id),
  merchant_id uuid references merchants(id),
  posted_at timestamptz default now(),
  memo text,
  order_id text,
  external_txid text,
  meta jsonb
);

create table if not exists splits(
  id bigserial primary key,
  journal_id bigint references journals(id),
  account_id bigint references accounts(id),
  dc char(1) check (dc in ('D','C')),
  amount bigint not null,
  currency text not null,
  meta jsonb
);
create index if not exists ix_splits_journal on splits(journal_id);

create table if not exists payouts(
  id bigserial primary key,
  tenant_id uuid references tenants(id),
  merchant_id uuid references merchants(id),
  mode text check (mode in ('T0','T1')),
  batch_time text check (batch_time in ('15:00','18:00')),
  status text check (status in ('SCHEDULED','SENT','FAILED')) default 'SCHEDULED',
  scheduled_for date not null,
  created_at timestamptz default now()
);

create table if not exists payout_items(
  id bigserial primary key,
  payout_id bigint references payouts(id),
  journal_id bigint references journals(id),
  amount bigint not null,
  currency text not null
);

create table if not exists api_clients(
  id uuid primary key default gen_random_uuid(),
  name text,
  hmac_secret text not null
);

create table if not exists audit_logs(
  id bigserial primary key,
  actor text,
  action text,
  target text,
  at timestamptz default now(),
  meta jsonb
);

create table if not exists config_flags(
  key text primary key,
  value jsonb
);
