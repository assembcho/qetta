
#!/usr/bin/env bash
set -e
echo "Risk evaluate sample:"
curl -s http://localhost:8080/risk/evaluate -H 'Content-Type: application/json' -d '{
  "orderId":"ord_demo",
  "merchantId":"m_demo",
  "amount":120000,
  "currency":"KRW",
  "features":{
    "merchantTenureDays":180,
    "gmv7d":30000000,
    "gmv30d":120000000,
    "refundRate30d":0.012,
    "chargebackRate90d":0.001,
    "highTicket":false,
    "ipCountryMismatch":false,
    "cardBinRisk":0.05,
    "deviceVelocity1h":2,
    "avgOrderValue30d":45000
  }
}' | jq . || true

echo "Lead submit (landing form POST):"
curl -s http://localhost:8080/leads -H 'Content-Type: application/json' -d '{
  "name":"Demo",
  "email":"demo@example.com",
  "role":"brand",
  "interest":"T+0 이용",
  "source":"script"
}' | jq . || true
