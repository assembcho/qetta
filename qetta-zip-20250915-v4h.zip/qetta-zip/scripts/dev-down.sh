
#!/usr/bin/env bash
docker compose down -v
