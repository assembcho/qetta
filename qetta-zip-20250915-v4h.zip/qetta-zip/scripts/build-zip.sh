#!/usr/bin/env bash
set -euo pipefail
ZIP_NAME=${1:-qetta-zip-$(date +%Y%m%d)}
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
echo "Creating $ZIP_NAME.zip ..."
zip -r "$ZIP_NAME.zip" .     -x "*/node_modules/*" ".git/*" "*/dist/*" "*/__pycache__/*" "*.DS_Store"     -x "*.log" ".env*" "infra/terraform/.terraform/*"
shasum -a 256 "$ZIP_NAME.zip" > "$ZIP_NAME.zip.sha256"
echo "Done: $ZIP_NAME.zip"
