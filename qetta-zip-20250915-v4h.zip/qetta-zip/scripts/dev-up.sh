
#!/usr/bin/env bash
set -e
docker compose up -d --build
echo "Waiting 6s for DB init..."; sleep 6
# Apply DDL
docker compose exec -T db psql -U qetta -d qetta -f /docker-entrypoint-initdb.d/ddl.sql || true
# Apply migrations
for f in docs/sql/migrations/*.sql; do
  [ -f "$f" ] && docker compose exec -T db psql -U qetta -d qetta -f "/docker-entrypoint-initdb.d/migrations/$(basename $f)" || true
done
# Seed
docker compose exec -T db psql -U qetta -d qetta -f /docker-entrypoint-initdb.d/seed.sql || true
echo "Services: API:8080, Risk:8081, Dashboard:3000, Landing:4000"
