# Qetta Demo Script (Day-1)
1) Start API: `cd apps/api && npm i && npm run dev`
2) Start Risk: `cd apps/risk && pip install -r requirements.txt && uvicorn main:app --port 9000`
3) Start Dashboard: `cd apps/dashboard && npm i && npm run dev`
4) POST /risk/evaluate with sample payload and observe decision.
5) Explore /ledger/entries (empty stub) and generate KPI via /report/kpi.
6) Announce “Verified” card: /registry/verify (stub data) and share link.
