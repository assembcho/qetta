
-- v003: leads table for landing signup
create table if not exists leads (
  id bigserial primary key,
  created_at timestamptz default now(),
  tenant_id uuid null,
  merchant_id uuid null,
  name text,
  email text not null,
  phone text,
  role text,                 -- influencer | brand | agency | other
  locale text default 'ko-KR',
  interest text,             -- free text
  source text,               -- landing | campaign | referral
  meta jsonb
);
create index if not exists ix_leads_email on leads(email);
