

### Start Landing (PWA) only
```bash
cd apps/landing
npm i
npm run dev   # http://localhost:4000
# set NEXT_PUBLIC_API_BASE if API is deployed elsewhere
```
