import React from 'react';
export default function Home(){
  return (
    <main style={{padding:24,fontFamily:'sans-serif'}}>
      <h1>Qetta Dashboard</h1>
      <p>Fair. Fast. Transparent. Explainable.</p>
      <ul>
        <li><a href="/api-docs">API Docs (refer to packages/common/openapi.yaml)</a></li>
        <li>Modules: SHIELD · LEDGER & PAYOUT · PULSE · Verified Registry</li>
      </ul>
    </main>
  );
}
