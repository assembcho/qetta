from fastapi import FastAPI
from pydantic import BaseModel
import hashlib

app = FastAPI()

class Features(BaseModel):
    merchantTenureDays: int | None = None
    gmv7d: int | None = None
    gmv30d: int | None = None
    refundRate30d: float | None = None
    chargebackRate90d: float | None = None
    highTicket: bool | None = None
    ipCountryMismatch: bool | None = None
    cardBinRisk: float | None = None
    deviceVelocity1h: int | None = None
    avgOrderValue30d: int | None = None

class RiskInput(BaseModel):
    orderId: str
    merchantId: str
    amount: int
    currency: str
    features: Features

def evaluate_risk(f: Features) -> float:
    r = 0.0
    r += 0.25*(f.refundRate30d or 0.0)
    r += 0.25*(f.chargebackRate90d or 0.0)
    r += 0.15*(1.0 if (f.highTicket or False) else 0.0)
    r += 0.10*(1.0 if (f.ipCountryMismatch or False) else 0.0)
    r += 0.15*(f.cardBinRisk or 0.0)
    vel = (f.deviceVelocity1h or 0)
    r += 0.10*min(vel/50.0, 1.0)
    tenure = (f.merchantTenureDays or 0)
    r -= 0.10*min(tenure/365.0, 1.0)
    gmv30 = (f.gmv30d or 0)
    r -= 0.05*min(gmv30/1_000_000_000.0, 1.0)
    r = max(0.0, min(1.0, r))
    return r

@app.get("/healthz")
def health(): return {"ok": True}

@app.post("/score")
def score(inp: RiskInput):
    risk = evaluate_risk(inp.features)
    hold = 0.04
    if risk <= 0.20: mode = "T0"
    elif risk <= 0.50: mode = "T1"
    else: mode = "TN"
    policy_hash = hashlib.sha256(b"policy_v1").hexdigest()[:16]
    model_hash = hashlib.sha256(b"rule_v1").hexdigest()[:16]
    return {
        "orderId": inp.orderId,
        "risk": risk,
        "mode": mode,
        "holdback": hold,
        "reasons": ["rule_based"],
        "policyHash": policy_hash,
        "modelHash": model_hash
    }
