
import Fastify from 'fastify';
import swagger from '@fastify/swagger';
import swaggerUI from '@fastify/swagger-ui';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import rawBody from 'fastify-raw-body';
import crypto from 'crypto';
import { Pool } from 'pg';
import client from 'prom-client';

const app = Fastify({ logger: true, bodyLimit: 1024*1024 });

// DB
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Metrics
const registry = new client.Registry();
client.collectDefaultMetrics({ register: registry });
const riskLatency = new client.Histogram({ name:'shield_latency_ms', help:'Latency for risk evaluate', buckets:[10,50,100,200,300,500,1000], registers:[registry]});
const decisionCounter = new client.Counter({ name:'shield_decision_total', help:'Decisions by mode', labelNames:['mode'], registers:[registry]});
const pulsePdfFail = new client.Counter({ name:'pulse_pdf_fail_total', help:'PDF failures', registers:[registry]});

// Utils
function verifyHmac(raw, secret, sig) {
  const mac = crypto.createHmac('sha256', secret).update(raw).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(sig)); } catch { return false; }
}
function evaluateRisk(f){
  let r=0;
  r+=0.25*(f.refundRate30d||0);
  r+=0.25*(f.chargebackRate90d||0);
  r+=0.15*(f.highTicket?1:0);
  r+=0.10*(f.ipCountryMismatch?1:0);
  r+=0.15*(f.cardBinRisk||0);
  r+=0.10*Math.min((f.deviceVelocity1h||0)/50,1);
  r-=0.10*Math.min((f.merchantTenureDays||0)/365,1);
  const gmv30n=Math.min((f.gmv30d||0)/1_000_000_000,1);
  r-=0.05*gmv30n;
  return Math.max(0,Math.min(1,r));
}
function decideMode(risk, band='B'){
  const hold={A:0.02,B:0.04,C:0.10}[band];
  if(risk<=0.20) return {mode:'T0',holdback:hold};
  if(risk<=0.50) return {mode:'T1',holdback:hold};
  return {mode:'TN',holdback:hold};
}

// Plugins
await app.register(rawBody, { field: 'rawBody', global: false, encoding: 'utf8', runFirst: true });
await app.register(cors, { origin: [/^http:\/\/localhost:(3000|4000)$/] });
await app.register(rateLimit, { max: 100, timeWindow: '1 minute' });
await app.register(swagger, { openapi: { info: { title: 'Qetta Agent API', version: '0.1.0' } } });
await app.register(swaggerUI, { routePrefix: '/docs' });

// Parsers (ensure raw body available)
app.addContentTypeParser('*', { parseAs: 'buffer' }, function (req, body, done) {
  req.rawBody = body;
  try { done(null, JSON.parse(body.toString())); } catch { done(null, {}); }
});

// Routes
app.get('/healthz', async () => ({ ok: true }));

app.get('/metrics', async (_req, reply)=>{
  reply.header('Content-Type', registry.contentType);
  return registry.metrics();
});

// Leads
app.post('/leads', async (req, reply)=>{
  const b = req.body||{};
  if(!b.email){ reply.code(400); return {error:'email required'}; }
  const clientPg = await pool.connect();
  try{
    await clientPg.query(
      `insert into leads(tenant_id, merchant_id, name, email, phone, role, locale, interest, source, meta)
       values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [b.tenantId||null, b.merchantId||null, b.name||null, b.email, b.phone||null, b.role||null, b.locale||'ko-KR', b.interest||null, b.source||'landing', b.meta?JSON.stringify(b.meta):null]
    );
  } finally { clientPg.release(); }
  return { ok: true };
});

// Webhook (HMAC + idempotent store)
app.post('/webhook/payment', { config: { rawBody: true } }, async (req, reply)=>{
  const sig = req.headers['x-qetta-signature'] || '';
  const secret = process.env.HMAC_SECRET || '';
  const raw = req.rawBody ? req.rawBody.toString() : JSON.stringify(req.body||{});
  if(!secret || !sig || !verifyHmac(raw, secret, sig)){ reply.code(401); return {error:'invalid signature'}; }
  const b = req.body||{};
  const idemp = b.idempotencyKey || b.id;
  if(!idemp){ reply.code(400); return {error:'id or idempotencyKey required'}; }
  const clientPg = await pool.connect();
  try{
    await clientPg.query(
      `insert into payments(id, tenant_id, merchant_id, amount, currency, created_at, raw, idempotency_key)
       values($1,$2,$3,$4,$5,now(),$6,$7) on conflict(idempotency_key) do nothing`,
      [b.id || idemp, b.tenantId||null, b.merchantId||null, b.amount||0, b.currency||'KRW', JSON.stringify(b), idemp]
    );
  } finally { clientPg.release(); }
  return { ack:true };
});

// Risk evaluate
app.post('/risk/evaluate', async (req)=>{
  const end = riskLatency.startTimer();
  const body = req.body||{};
  const f = body.features||{};
  const risk = evaluateRisk(f);
  const {mode,holdback} = decideMode(risk,'B');
  const policyHash = crypto.createHash('sha256').update('pol_v1').digest('hex').slice(0,8);
  const modelHash = crypto.createHash('sha256').update('mdl_rule_v1').digest('hex').slice(0,8);
  // usage meter
  const clientPg = await pool.connect();
  try{
    await clientPg.query(
      `insert into usage_meters(api_name, tenant_id, merchant_id, count, last_called_at)
       values('risk_evaluate',$1,$2,1,now())
       on conflict do nothing`, [body.tenantId||null, body.merchantId||null]
    );
    await clientPg.query(
      `update usage_meters set count=count+1, last_called_at=now()
       where api_name='risk_evaluate' and tenant_id is not distinct from $1 and merchant_id is not distinct from $2`,
       [body.tenantId||null, body.merchantId||null]
    );
  } finally { clientPg.release(); }
  decisionCounter.labels(mode).inc(1);
  end();
  return { orderId: body.orderId||'unknown', risk, mode, holdback, reasons:[], policyHash, modelHash };
});

// KPI & PDF (stub)
app.get('/report/kpi', async (req)=>{
  const date = (req.query?.date)||new Date().toISOString().slice(0,10);
  return { date, gmv:0, orders:0, t0Share:0, refund7d:0 };
});
app.post('/report/kpi/pdf', async (req, reply)=>{
  try {
    const date = (req.body?.date)||new Date().toISOString().slice(0,10);
    const kpi = req.body?.kpi || { gmv:0, orders:0, t0Share:0, refund7d:0 };
    const fs = await import('fs');
    const path = await import('path');
    const dir = process.env.PDF_DIR || '/tmp';
    const filename = `KPI_${date}.pdf`;
    const full = path.join(dir, filename);
    await fs.promises.writeFile(full, JSON.stringify({date,kpi, note:'Replace with Puppeteer render.'}, null, 2), 'utf-8');
    return { ok:true, file: full };
  } catch(e){
    pulsePdfFail.inc(1);
    reply.code(500);
    return { ok:false, error:String(e) };
  }
});

// IFRS light pack
app.get('/ifrs/pack', async (req)=>{
  const clientPg = await pool.connect();
  try {
    const income = await clientPg.query(`
      select coalesce(sum(case when a.code like '41%' then s.amount else 0 end),0) as income
      from splits s join journals j on s.journal_id=j.id join accounts a on s.account_id=a.id
    `);
    const expense = await clientPg.query(`
      select coalesce(sum(case when a.code like '51%' or a.code like '52%' then s.amount else 0 end),0) as expense
      from splits s join journals j on s.journal_id=j.id join accounts a on s.account_id=a.id
    `);
    const assets = await clientPg.query(`
      select coalesce(sum(s.amount*(case when s.dc='D' then 1 else -1 end)),0) as assets
      from splits s join accounts a on s.account_id=a.id
      where a.code like '10%'
    `);
    const liab = await clientPg.query(`
      select coalesce(sum(s.amount*(case when s.dc='C' then 1 else -1 end)),0) as liabilities
      from splits s join accounts a on s.account_id=a.id
      where a.code like '21%'
    `);
    const rev = Number(income.rows[0].income);
    const exp = Number(expense.rows[0].expense);
    const ast = Number(assets.rows[0].assets);
    const lib = Number(liab.rows[0].liabilities);
    return { pl:{ revenue:rev, expense:exp, profit: rev-exp }, bs:{ assets:ast, liabilities:lib, equity: ast-lib }, cf:{ op:null, inv:null, fin:null } };
  } finally { clientPg.release(); }
});

// Start
const port = process.env.API_PORT ? Number(process.env.API_PORT) : 8080;
app.listen({ port, host: '0.0.0.0' }).then(()=>{
  app.log.info(`API listening on ${port}`);
});
