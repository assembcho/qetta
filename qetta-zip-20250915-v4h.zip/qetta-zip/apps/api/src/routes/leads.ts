
import { FastifyInstance } from 'fastify';
import { withTx } from '../lib/db.js';

export default async function leadsRoutes(app: FastifyInstance){
  app.post('/leads', async (req:any, reply) => {
    const b = req.body||{};
    if (!b.email) { reply.code(400); return {error:'email required'}; }
    await withTx(async (c)=>{
      await c.query(
        `insert into leads(tenant_id, merchant_id, name, email, phone, role, locale, interest, source, meta)
         values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [b.tenantId||null, b.merchantId||null, b.name||null, b.email, b.phone||null, b.role||null, b.locale||'ko-KR', b.interest||null, b.source||'landing', b.meta?JSON.stringify(b.meta):null]
      );
    });
    return { ok: true };
  });
}
