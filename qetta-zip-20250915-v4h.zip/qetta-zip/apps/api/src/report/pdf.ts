
import puppeteer from 'puppeteer';

export async function generateKpiPdf(data:{date:string; gmv:number; orders:number; t0Share:number; refund7d:number;}): Promise<Buffer>{
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Qetta KPI</title></head>
  <body style="font-family:sans-serif;padding:24px">
    <h1>Qetta KPI — ${data.date}</h1>
    <ul>
      <li>GMV: ${data.gmv}</li>
      <li>Orders: ${data.orders}</li>
      <li>T+0 Share: ${(data.t0Share*100).toFixed(2)}%</li>
      <li>Refund(7d): ${(data.refund7d*100).toFixed(2)}%</li>
    </ul>
    <p style="margin-top:24px">Numbers are aggregated from ledger.</p>
  </body></html>`;
  const browser = await puppeteer.launch({args:['--no-sandbox']});
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle0' });
  const pdf = await page.pdf({ format: 'A4' });
  await browser.close();
  return pdf;
}
