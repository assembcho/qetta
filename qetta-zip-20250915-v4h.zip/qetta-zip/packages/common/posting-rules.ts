export const ACCOUNTS = {
  CASH_KRW: '1010:Cash:KRW',
  STABLECOIN_USDC: '1020:Stablecoin:USDC',
  MERCHANT_PAYABLE: '2100:Merchant Payable',
  HOLDBACK: '2110:Holdback',
  PLATFORM_FEE: '4100:Platform Fee',
  T0_FEE: '4110:T0 Fee',
  FUNDING_COST: '5100:Funding Cost',
  EXPECTED_LOSS: '5200:Expected Loss'
} as const;

export type Entry = { account: string; dc: 'D'|'C'; amount: number; currency: string; meta?: any };

export function verifyBalanced(entries: Entry[]) {
  const sumD = entries.filter(e=>e.dc==='D').reduce((a,b)=>a+b.amount,0);
  const sumC = entries.filter(e=>e.dc==='C').reduce((a,b)=>a+b.amount,0);
  if(sumD !== sumC) throw new Error('DEBIT_CREDIT_MISMATCH');
  return true;
}
