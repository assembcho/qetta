export type RiskInput = {
  orderId: string;
  merchantId: string;
  amount: number;
  currency: string;
  features: Record<string, any>;
};
export type RiskDecision = {
  orderId: string;
  risk: number;
  mode: 'T0'|'T1'|'TN'|'MANUAL';
  holdback: number;
  reasons: string[];
  policyHash: string;
  modelHash: string;
};
