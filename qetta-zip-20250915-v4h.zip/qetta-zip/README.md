# Qetta ZIP Product (MVP → Beta → Enterprise)

Full-stack scaffold for Qetta's SHIELD · LEDGER & PAYOUT · PULSE · Verified Registry.
This bundle includes API (NestJS/Fastify), Risk service (FastAPI), Dashboard (Next.js),
DB schema (PostgreSQL), OpenAPI, IaC skeletons, CI/CD stubs, and build scripts.

## Quick Start (dev)
1) Install: Node 20+, pnpm or npm, Python 3.11+, Docker (optional)
2) Copy env: `cp .env.example .env` and adjust variables
3) DB: run a local Postgres (or use Docker) and apply SQL in `infra/db/migrations/001_init.sql`
4) API: `cd apps/api && pnpm i && pnpm dev` (or `npm i && npm run dev`)
5) Risk: `cd apps/risk && python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt && uvicorn main:app --reload --port 9000`
6) Dashboard: `cd apps/dashboard && pnpm i && pnpm dev` then open http://localhost:3000
7) Build ZIP: `make zip` from repo root

## Modules
- SHIELD: Risk & settlement decision (`/risk/evaluate`, p95<500ms target)
- LEDGER & PAYOUT: Double-entry journals & batch payouts (15:00/18:00)
- PULSE: KPI API + 06:00 PDF (stub)
- Verified Registry: Influencer trust card snapshot

## Important
- Decisions are rule+model; LLM is for explanations only.
- All figures come from the double-entry ledger (A=L+E, Trial Balance=0).
- Stablecoin features must be gated by locale/partner and appear as TxID notes in journals.
