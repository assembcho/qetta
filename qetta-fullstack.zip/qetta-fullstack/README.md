# 🚀 QETTA Full-Stack Platform

## 📋 Overview

QETTA is a production-ready influencer marketing platform with real-time settlement, risk assessment, and comprehensive analytics. This full-stack implementation includes:

- **6 Microservices**: Gateway API, Risk (SHIELD), Ledger, Payout, Pulse, Registry
- **React Frontend**: Responsive web application with brand/creator dashboards
- **Database**: PostgreSQL with Prisma ORM
- **Caching**: Redis for performance optimization
- **Security**: HMAC authentication, JWT tokens, AES-256 encryption
- **DevOps**: Docker, Kubernetes-ready, CI/CD pipelines

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         Frontend (React)                     │
│  • Landing Page  • Brand Dashboard  • Creator Dashboard      │
└──────────────────────┬──────────────────────────────────────┘
                       │ HTTPS
┌──────────────────────▼──────────────────────────────────────┐
│                    Gateway API (Port 3000)                   │
│  • Authentication  • Rate Limiting  • Request Routing        │
└──────────────────────┬──────────────────────────────────────┘
                       │ Internal HTTP/gRPC
┌──────────────────────▼──────────────────────────────────────┐
│                      Microservices Layer                     │
├─────────────────────────────────────────────────────────────┤
│  Risk Service    │  Ledger Service │  Payout Service        │
│  (Port 3001)     │  (Port 3002)    │  (Port 3003)           │
├─────────────────────────────────────────────────────────────┤
│  Pulse Service   │  Registry Service                         │
│  (Port 3004)     │  (Port 3005)                             │
└─────────────────────┬────────────────────────────────────────┘
                      │
┌─────────────────────▼────────────────────────────────────────┐
│               Data Layer (PostgreSQL + Redis)                 │
└───────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Node.js 20+
- Docker & Docker Compose
- PostgreSQL 16
- Redis 7+

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/qetta-fullstack.git
cd qetta-fullstack

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Start services with Docker
docker-compose up -d

# Run database migrations
npm run db:migrate

# Seed initial data
npm run db:seed

# Start development servers
npm run dev
```

### Access Points

- **Frontend**: http://localhost:3006
- **Gateway API**: http://localhost:3000
- **Risk Service**: http://localhost:3001
- **Ledger Service**: http://localhost:3002
- **Payout Service**: http://localhost:3003
- **Pulse Service**: http://localhost:3004
- **Registry Service**: http://localhost:3005
- **PostgreSQL**: localhost:5432
- **Redis**: localhost:6379

## 📦 Project Structure

```
qetta-fullstack/
├── apps/
│   ├── frontend/          # React application
│   ├── gateway-api/       # API Gateway
│   ├── risk-service/      # SHIELD risk engine
│   ├── ledger-service/    # Double-entry bookkeeping
│   ├── payout-service/    # Batch payout processing
│   ├── pulse-service/     # Analytics & reporting
│   └── registry-service/  # Badge & certification
├── packages/
│   ├── shared-lib/        # Shared utilities & types
│   ├── connectors/        # Bank/payment connectors
│   └── observability/     # Monitoring & logging
├── infra/
│   ├── db/               # Database schema & migrations
│   ├── docker/           # Docker configurations
│   ├── k8s/              # Kubernetes manifests
│   └── github-actions/   # CI/CD workflows
├── docker-compose.yml    # Development orchestration
├── docker-compose.prod.yml # Production orchestration
├── turbo.json           # Monorepo configuration
└── package.json         # Root package configuration
```

## 💼 Features

### For Brands
- **Campaign Management**: Create and monitor influencer campaigns
- **Risk Assessment**: Real-time SHIELD risk scoring
- **Analytics Dashboard**: Comprehensive ROI tracking
- **Instant Settlement**: T+0 payout capability
- **Compliance Tools**: Platform policy adherence

### For Creators
- **Earnings Dashboard**: Real-time revenue tracking
- **Instant Payouts**: Request T+0 settlements
- **Performance Analytics**: Engagement metrics
- **Content Management**: Track posts and campaigns
- **Badge System**: Verified creator certification

### Platform Features
- **HMAC Authentication**: Secure API access
- **Multi-Currency Support**: KRW, USD, EUR, USDC, USDT
- **Double-Entry Ledger**: Financial accuracy
- **Event Sourcing**: Complete audit trail
- **Rate Limiting**: API protection
- **Observability**: Prometheus metrics, OpenTelemetry tracing

## 🔐 Security

- **Authentication**: HMAC raw signature validation
- **Authorization**: JWT-based service-to-service auth
- **Encryption**: AES-256-GCM for PII data
- **IP Allowlisting**: CIDR-based access control
- **Idempotency**: Exactly-once processing
- **Kill Switch**: Emergency transaction suspension

## 🏃‍♂️ Development

### Running Services

```bash
# Start all services
npm run dev

# Start backend only
npm run dev:backend

# Start frontend only
npm run dev:frontend

# Run specific service
cd apps/gateway-api && npm run dev
```

### Testing

```bash
# Run all tests
npm run test

# Run specific service tests
cd apps/risk-service && npm run test

# Run integration tests
npm run test:integration

# Run load tests
npm run test:load
```

### Database Management

```bash
# Create migration
npx prisma migrate dev --name your_migration_name

# Apply migrations
npm run db:migrate

# Reset database
npm run db:reset

# View database
npx prisma studio
```

## 📊 API Documentation

### Authentication

All API requests require HMAC signature:

```javascript
const signature = crypto
  .createHmac('sha256', API_SECRET)
  .update(timestamp + method + path + body)
  .digest('hex');

headers = {
  'X-Signature': signature,
  'X-Timestamp': timestamp,
  'X-Client-Id': clientId
};
```

### Core Endpoints

#### Risk Assessment
```
POST /api/v1/risk/evaluate
{
  "merchantId": "string",
  "transactionAmount": number,
  "creatorId": "string"
}
```

#### Create Payout
```
POST /api/v1/payouts/create
{
  "creatorId": "string",
  "amount": number,
  "currency": "KRW",
  "type": "instant"
}
```

#### Get Analytics
```
GET /api/v1/analytics/dashboard?period=30d
```

## 🐳 Docker Deployment

### Development
```bash
docker-compose up -d
```

### Production
```bash
docker-compose -f docker-compose.prod.yml up -d
```

### Kubernetes
```bash
kubectl apply -f infra/k8s/
```

## 📈 Performance

- **Risk API**: p95 < 500ms
- **Settlement Speed**: T+0 (same day)
- **Throughput**: 10,000 RPS
- **Availability**: 99.9% SLA
- **Database**: <10ms query time

## 🧪 Monitoring

- **Metrics**: Prometheus + Grafana
- **Tracing**: OpenTelemetry + Jaeger
- **Logging**: ELK Stack
- **Alerts**: PagerDuty integration
- **Health Checks**: /health endpoints

## 🚢 Production Deployment

### Environment Variables

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/qetta
REDIS_URL=redis://localhost:6379

# Security
JWT_SECRET=your-jwt-secret
HMAC_SECRET=your-hmac-secret
ENCRYPTION_KEY=your-32-byte-key

# Services
GATEWAY_URL=http://localhost:3000
RISK_SERVICE_URL=http://localhost:3001
LEDGER_SERVICE_URL=http://localhost:3002

# External APIs
BANK_API_KEY=your-bank-api-key
CIRCLE_API_KEY=your-circle-api-key
```

### Deployment Checklist

- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] SSL certificates installed
- [ ] Load balancer configured
- [ ] Monitoring alerts set up
- [ ] Backup strategy implemented
- [ ] Rate limiting configured
- [ ] WAF rules applied
- [ ] DDoS protection enabled
- [ ] Logging aggregation configured

## 📝 License

MIT License - see LICENSE file for details

## 🤝 Contributing

Please read CONTRIBUTING.md for contribution guidelines.

## 📞 Support

- Email: support@qetta.io
- Documentation: https://docs.qetta.io
- Status Page: https://status.qetta.io

---

**Built with ❤️ for the future of influencer marketing**
