import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createProxyMiddleware } from 'http-proxy-middleware';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { PrismaClient } from '@prisma/client';
import Redis from 'ioredis';
import winston from 'winston';
import { z } from 'zod';

// Initialize services
const app = express();
const prisma = new PrismaClient();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Logger configuration
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      ),
    }),
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
  ],
});

// Configuration
const config = {
  port: process.env.PORT || 3000,
  jwtSecret: process.env.JWT_SECRET || 'change-this-in-production',
  hmacSecret: process.env.HMAC_SECRET || 'change-this-in-production',
  services: {
    risk: process.env.RISK_SERVICE_URL || 'http://localhost:3001',
    ledger: process.env.LEDGER_SERVICE_URL || 'http://localhost:3002',
    payout: process.env.PAYOUT_SERVICE_URL || 'http://localhost:3003',
    pulse: process.env.PULSE_SERVICE_URL || 'http://localhost:3004',
    registry: process.env.REGISTRY_SERVICE_URL || 'http://localhost:3005',
  },
};

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3006',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    return req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || '';
  },
  handler: (req, res) => {
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
    res.status(429).json({
      error: 'Too many requests',
      message: 'Please try again later',
    });
  },
});

app.use('/api/', limiter);

// HMAC Authentication Middleware
const hmacAuthSchema = z.object({
  'x-signature': z.string(),
  'x-timestamp': z.string(),
  'x-client-id': z.string(),
});

const verifyHmacSignature = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  try {
    const headers = hmacAuthSchema.parse({
      'x-signature': req.headers['x-signature'],
      'x-timestamp': req.headers['x-timestamp'],
      'x-client-id': req.headers['x-client-id'],
    });

    const timestamp = parseInt(headers['x-timestamp']);
    const now = Date.now();
    
    // Check timestamp is within 5 minutes
    if (Math.abs(now - timestamp) > 5 * 60 * 1000) {
      return res.status(401).json({ error: 'Request timestamp expired' });
    }

    // Get API key from database
    const apiKey = await prisma.apiKey.findUnique({
      where: { key: headers['x-client-id'] },
      include: { user: true },
    });

    if (!apiKey) {
      return res.status(401).json({ error: 'Invalid API key' });
    }

    // Check if API key is expired
    if (apiKey.expiresAt && apiKey.expiresAt < new Date()) {
      return res.status(401).json({ error: 'API key expired' });
    }

    // Construct message for signature
    const method = req.method;
    const path = req.originalUrl;
    const body = JSON.stringify(req.body);
    const message = `${timestamp}${method}${path}${body}`;

    // Verify signature
    const expectedSignature = crypto
      .createHmac('sha256', config.hmacSecret)
      .update(message)
      .digest('hex');

    if (headers['x-signature'] !== expectedSignature) {
      logger.warn(`Invalid HMAC signature for client: ${headers['x-client-id']}`);
      return res.status(401).json({ error: 'Invalid signature' });
    }

    // Update last used timestamp
    await prisma.apiKey.update({
      where: { id: apiKey.id },
      data: { lastUsed: new Date() },
    });

    // Attach user to request
    (req as any).user = apiKey.user;
    (req as any).apiKey = apiKey;

    next();
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Missing required authentication headers' });
    }
    logger.error('HMAC verification error:', error);
    return res.status(500).json({ error: 'Authentication error' });
  }
};

// JWT Authentication for internal services
const generateServiceToken = (service: string) => {
  return jwt.sign(
    { service, iat: Date.now() },
    config.jwtSecret,
    { expiresIn: '1h' }
  );
};

// Idempotency middleware
const idempotencyMiddleware = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const idempotencyKey = req.headers['idempotency-key'] as string;
  
  if (!idempotencyKey) {
    return next();
  }

  const cacheKey = `idempotency:${idempotencyKey}`;
  const cached = await redis.get(cacheKey);

  if (cached) {
    const result = JSON.parse(cached);
    return res.status(result.status).json(result.body);
  }

  // Store original send function
  const originalSend = res.send;
  
  // Override send to cache the response
  res.send = function(data: any) {
    if (res.statusCode < 400) {
      const result = {
        status: res.statusCode,
        body: JSON.parse(data),
      };
      redis.setex(cacheKey, 86400, JSON.stringify(result)); // Cache for 24 hours
    }
    return originalSend.call(this, data);
  };

  next();
};

// Health check endpoint
app.get('/health', async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    await redis.ping();
    
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        redis: 'connected',
      },
    });
  } catch (error) {
    logger.error('Health check failed:', error);
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error.message,
    });
  }
});

// API Routes

// Authentication endpoints
app.post('/api/v1/auth/register', async (req, res) => {
  try {
    const { email, password, name, role } = req.body;
    
    // Validate input
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      return res.status(409).json({ error: 'User already exists' });
    }

    // Create user (password should be hashed in production)
    const user = await prisma.user.create({
      data: {
        email,
        name,
        role: role || 'BRAND',
      },
    });

    // Generate API key
    const apiKey = await prisma.apiKey.create({
      data: {
        userId: user.id,
        key: crypto.randomBytes(32).toString('hex'),
        name: 'Default API Key',
        permissions: ['read', 'write'],
      },
    });

    res.status(201).json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      apiKey: apiKey.key,
    });
  } catch (error) {
    logger.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Risk Service Proxy
app.use('/api/v1/risk', 
  verifyHmacSignature,
  idempotencyMiddleware,
  createProxyMiddleware({
    target: config.services.risk,
    changeOrigin: true,
    pathRewrite: { '^/api/v1/risk': '' },
    headers: {
      'Authorization': `Bearer ${generateServiceToken('gateway')}`,
    },
    logLevel: 'debug',
    logger,
  })
);

// Ledger Service Proxy
app.use('/api/v1/ledger',
  verifyHmacSignature,
  idempotencyMiddleware,
  createProxyMiddleware({
    target: config.services.ledger,
    changeOrigin: true,
    pathRewrite: { '^/api/v1/ledger': '' },
    headers: {
      'Authorization': `Bearer ${generateServiceToken('gateway')}`,
    },
    logLevel: 'debug',
    logger,
  })
);

// Payout Service Proxy
app.use('/api/v1/payouts',
  verifyHmacSignature,
  idempotencyMiddleware,
  createProxyMiddleware({
    target: config.services.payout,
    changeOrigin: true,
    pathRewrite: { '^/api/v1/payouts': '' },
    headers: {
      'Authorization': `Bearer ${generateServiceToken('gateway')}`,
    },
    logLevel: 'debug',
    logger,
  })
);

// Analytics Service Proxy
app.use('/api/v1/analytics',
  verifyHmacSignature,
  createProxyMiddleware({
    target: config.services.pulse,
    changeOrigin: true,
    pathRewrite: { '^/api/v1/analytics': '' },
    headers: {
      'Authorization': `Bearer ${generateServiceToken('gateway')}`,
    },
    logLevel: 'debug',
    logger,
  })
);

// Registry Service Proxy
app.use('/api/v1/registry',
  verifyHmacSignature,
  createProxyMiddleware({
    target: config.services.registry,
    changeOrigin: true,
    pathRewrite: { '^/api/v1/registry': '' },
    headers: {
      'Authorization': `Bearer ${generateServiceToken('gateway')}`,
    },
    logLevel: 'debug',
    logger,
  })
);

// Campaign Management Endpoints
app.post('/api/v1/campaigns', verifyHmacSignature, idempotencyMiddleware, async (req, res) => {
  try {
    const user = (req as any).user;
    
    // Check if user is a merchant
    const merchant = await prisma.merchant.findUnique({
      where: { userId: user.id },
    });

    if (!merchant) {
      return res.status(403).json({ error: 'Only merchants can create campaigns' });
    }

    const campaign = await prisma.campaign.create({
      data: {
        ...req.body,
        merchantId: merchant.id,
      },
    });

    // Emit event for other services
    await redis.publish('events', JSON.stringify({
      type: 'CAMPAIGN_CREATED',
      payload: campaign,
      timestamp: new Date().toISOString(),
    }));

    res.status(201).json(campaign);
  } catch (error) {
    logger.error('Campaign creation error:', error);
    res.status(500).json({ error: 'Failed to create campaign' });
  }
});

app.get('/api/v1/campaigns', verifyHmacSignature, async (req, res) => {
  try {
    const user = (req as any).user;
    const { status, page = 1, limit = 20 } = req.query;

    const where: any = {};
    
    // Filter by merchant if not admin
    if (user.role !== 'ADMIN') {
      const merchant = await prisma.merchant.findUnique({
        where: { userId: user.id },
      });
      
      if (merchant) {
        where.merchantId = merchant.id;
      }
    }

    if (status) {
      where.status = status;
    }

    const campaigns = await prisma.campaign.findMany({
      where,
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        merchant: {
          select: {
            companyName: true,
          },
        },
        _count: {
          select: {
            creators: true,
            posts: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    const total = await prisma.campaign.count({ where });

    res.json({
      campaigns,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    logger.error('Campaign listing error:', error);
    res.status(500).json({ error: 'Failed to list campaigns' });
  }
});

// Transaction endpoints
app.post('/api/v1/transactions', verifyHmacSignature, idempotencyMiddleware, async (req, res) => {
  try {
    const user = (req as any).user;
    
    const merchant = await prisma.merchant.findUnique({
      where: { userId: user.id },
    });

    if (!merchant) {
      return res.status(403).json({ error: 'Only merchants can create transactions' });
    }

    const transaction = await prisma.transaction.create({
      data: {
        ...req.body,
        merchantId: merchant.id,
        reference: `TXN-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`,
      },
    });

    // Send to ledger service for processing
    await redis.publish('events', JSON.stringify({
      type: 'TRANSACTION_CREATED',
      payload: transaction,
      timestamp: new Date().toISOString(),
    }));

    res.status(201).json(transaction);
  } catch (error) {
    logger.error('Transaction creation error:', error);
    res.status(500).json({ error: 'Failed to create transaction' });
  }
});

// Error handling middleware
app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined,
  });
});

// Start server
const server = app.listen(config.port, () => {
  logger.info(`Gateway API running on port ${config.port}`);
  logger.info('Connected services:', config.services);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  server.close(() => {
    logger.info('Server closed');
  });
  
  await prisma.$disconnect();
  await redis.quit();
  
  process.exit(0);
});

export default app;
