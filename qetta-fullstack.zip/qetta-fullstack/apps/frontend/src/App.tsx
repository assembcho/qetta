import React, { useState, useEffect, useRef, useMemo, createContext, useContext, useCallback, Suspense, memo } from 'react';
import { 
  ChevronRight, Check, ArrowRight, Shield, Zap, BarChart3,
  DollarSign, Clock, AlertCircle, TrendingUp, Users, 
  Menu, X, ChevronDown, CheckCircle,
  Database, Lock, Globe, Smartphone, Monitor, Loader2,
  ArrowUpRight, ArrowDownRight, Info, Bell, Search, Filter,
  Settings, LogOut, Home, CreditCard, Sparkles,
  MessageSquare, Heart, Share2, Award, Download
} from 'lucide-react';
import { toast } from "sonner";
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar, 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { useVirtualizer } from '@tanstack/react-virtual';

// ========== TYPES ==========
type Viewport = {
  isMobile: boolean;
  isTablet: boolean;
  isDesktop: boolean;
  width: number;
};

type QettaContextType = {
  theme: 'light' | 'dark';
  user: any;
  activeView: string;
  viewport: Viewport;
  showNotification: (title: string, description: string, type?: string) => void;
};

type Campaign = {
  id: number;
  name: string;
  creators: number;
  gmv: number;
  roi: number;
  risk: number;
  status: string;
};

type Transaction = {
  id: number;
  brand: string;
  amount: number;
  status: string;
  date: string;
  change: string;
};

type Post = {
  id: number;
  author: string;
  time: string;
  image: string;
  caption: string;
  likes: number;
  comments: number;
  liked: boolean;
};

type MetricCardProps = {
  title: string;
  value: string | number;
  change?: string;
  icon: React.ElementType;
  trend?: 'up' | 'down';
  delay?: number;
};

type AnimatedCardProps = {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  speed?: number;
};

type PulseButtonProps = {
  children: React.ReactNode;
  className?: string;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'emerald';
  disabled?: boolean;
  [key: string]: any;
};

type ContentFeedItemProps = {
  post: Post;
  onLike: (id: number) => void;
  onComment: (id: number) => void;
};

type ExportMenuProps = {
  data: any[];
  type?: string;
  className?: string;
};

type ChartProps = {
  data: any[];
  type?: 'area' | 'bar' | 'line';
  height?: number;
};

type NavigationProps = {
  viewport: Viewport;
  activeView: string;
  setActiveView: (view: string) => void;
};

// ========== CONSTANTS & CONFIG ==========
const ANIMATION_DURATION = 300;
const TRANSITION_EASE = 'cubic-bezier(0.4, 0, 0.2, 1)';

// ========== CONTEXT ==========
const QettaContext = createContext<QettaContextType>({
  theme: 'light',
  user: null,
  activeView: 'landing',
  viewport: { isMobile: false, isTablet: false, isDesktop: true, width: 1920 },
  showNotification: () => {}
});

// ========== UTILITIES ==========
/**
 * Formats a number as currency in Korean Won
 */
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('ko-KR', {
    style: 'currency',
    currency: 'KRW',
    maximumFractionDigits: 0,
  }).format(amount);
};

/**
 * Formats a number with K/M suffixes for thousands/millions
 */
const formatNumber = (num: number): string => {
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
  return num.toString();
};

/**
 * Utility for conditional className joining
 */
const cn = (...classes: (string | boolean | undefined)[]): string => 
  classes.filter(Boolean).join(' ');

/**
 * Image component with fallback on error
 */
const ImageWithFallback = memo(function ImageWithFallback(props: React.ImgHTMLAttributes<HTMLImageElement> & { style?: React.CSSProperties }) {
  const [didError, setDidError] = useState(false);
  const { src, alt, style, className, ...rest } = props;

  return didError ? (
    <div
      className={`inline-block bg-gray-100 text-center align-middle ${className ?? ''}`}
      style={style}
    >
      <div className="flex items-center justify-center w-full h-full">
        <img 
          src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODgiIGhlaWdodD0iODgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBvcGFjaXR5PSIuMyIgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIzLjciPjxyZWN0IHg9IjE2IiB5PSIxNiIgd2lkdGg9IjU2IiBoZWlnaHQ9IjU2IiByeD0iNiIvPjxwYXRoIGQ9Im0xNiA1OCAxNi0xOCAzMiAzMiIvPjxjaXJjbGUgY3g9IjUzIiBjeT0iMzUiIHI9IjciLz48L3N2Zz4KCg==" 
          alt="Error loading image" 
          {...rest} 
          data-original-url={src} 
        />
      </div>
    </div>
  ) : (
    <img 
      src={src} 
      alt={alt} 
      className={className} 
      style={style} 
      {...rest} 
      onError={() => setDidError(true)} 
    />
  );
});

// Export functions
/**
 * Exports data as CSV file
 */
const exportToCSV = (data: any[], filename = 'export.csv'): void => {
  if (!data || !data.length) return;
  
  // Convert data to CSV format
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => headers.map(header => {
      const cell = row[header];
      return typeof cell === 'string' && cell.includes(',') ? `"${cell}"` : cell;
    }).join(','))
  ].join('\n');
  
  // Create download link
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

/**
 * Exports data as JSON file
 */
const exportToJSON = (data: any, filename = 'export.json'): void => {
  if (!data) return;
  
  const jsonContent = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonContent], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// ========== ERROR BOUNDARY ==========
interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    console.error("Error caught by boundary:", error, errorInfo);
  }

  render(): React.ReactNode {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
          <h2 className="text-2xl font-bold mb-2 text-gray-800">Something went wrong</h2>
          <p className="text-gray-600 mb-6 max-w-md">
            We've encountered an error. Please try refreshing the page or contact support if the problem persists.
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-black text-white font-medium rounded-lg hover:bg-gray-800 transition-colors"
          >
            Refresh Page
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

// ========== HOOKS ==========
/**
 * Custom hook to detect viewport size
 */
const useViewport = (): Viewport => {
  const [viewport, setViewport] = useState<Viewport>({
    isMobile: false,
    isTablet: false,
    isDesktop: true,
    width: typeof window !== 'undefined' ? window.innerWidth : 1920
  });

  useEffect(() => {
    const handleResize = (): void => {
      const width = window.innerWidth;
      setViewport({
        isMobile: width < 640,
        isTablet: width >= 640 && width < 1024,
        isDesktop: width >= 1024,
        width
      });
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return viewport;
};

/**
 * Custom hook for smooth number animation
 */
const useAnimatedValue = (value: number, duration = 2000): number => {
  const [displayValue, setDisplayValue] = useState(0);
  
  useEffect(() => {
    let startTime: number | undefined;
    let animationFrame: number;
    
    const animate = (timestamp: number): void => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      setDisplayValue(Math.floor(value * easeOutQuart));
      
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };
    
    animationFrame = requestAnimationFrame(animate);
    
    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [value, duration]);
  
  return displayValue;
};

/**
 * Custom hook for notifications
 */
const useNotifications = () => {
  const showNotification = useCallback((title: string, description: string, type = 'default'): void => {
    toast[type](title, {
      description,
      position: 'top-right',
      duration: 4000,
    });
  }, []);

  return { showNotification };
};

// ========== ANIMATED COMPONENTS ==========
/**
 * Card component with entrance animation
 */
const AnimatedCard: React.FC<AnimatedCardProps> = memo(function AnimatedCard({ 
  children, 
  delay = 0, 
  className = '', 
  speed = 1 
}) {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay / speed);
    return () => clearTimeout(timer);
  }, [delay, speed]);
  
  return (
    <div 
      className={cn(
        className,
        "transition-all duration-700",
        isVisible 
          ? "opacity-100 translate-y-0" 
          : "opacity-0 translate-y-4"
      )}
      style={{
        transitionDelay: `${delay / speed}ms`,
        transitionTimingFunction: TRANSITION_EASE,
        transitionDuration: `${700 / speed}ms`
      }}
    >
      {children}
    </div>
  );
});

/**
 * Button with pulse animation on click
 */
const PulseButton: React.FC<PulseButtonProps> = memo(function PulseButton({ 
  children, 
  className = '', 
  onClick, 
  variant = 'primary', 
  disabled = false,
  ...props 
}) {
  const [isPulsing, setIsPulsing] = useState(false);
  
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>): void => {
    if (disabled) return;
    
    setIsPulsing(true);
    setTimeout(() => setIsPulsing(false), 600);
    onClick?.(e);
  };
  
  const baseClasses = "relative overflow-hidden transition-all duration-300 font-medium";
  const variantClasses = {
    primary: "bg-black text-white hover:bg-gray-900",
    secondary: "bg-white text-black border border-gray-200 hover:bg-gray-50",
    ghost: "text-gray-600 hover:text-black",
    emerald: "bg-emerald-600 text-white hover:bg-emerald-700"
  };
  
  return (
    <button
      onClick={handleClick}
      className={cn(
        baseClasses, 
        variantClasses[variant], 
        disabled && "opacity-60 cursor-not-allowed",
        className
      )}
      disabled={disabled}
      {...props}
    >
      {isPulsing && !disabled && (
        <span 
          className="absolute inset-0 bg-white/20 animate-ping"
          style={{ animationDuration: '600ms' }}
        />
      )}
      <span className="relative z-10">{children}</span>
    </button>
  );
});

/**
 * Component for loading placeholders
 */
const SkeletonLoader: React.FC<{className?: string, variant?: 'text' | 'title' | 'card' | 'avatar'}> = memo(
  function SkeletonLoader({ className = '', variant = 'text' }) {
    const variants = {
      text: 'h-4 rounded',
      title: 'h-6 rounded',
      card: 'h-32 rounded-lg',
      avatar: 'w-10 h-10 rounded-full'
    };
    
    return (
      <div className={cn(
        "animate-pulse bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%]",
        variants[variant],
        className
      )} />
    );
  }
);

// ========== SHARED COMPONENTS ==========
/**
 * Toast notification component
 */
const NotificationToast: React.FC<{
  title: string;
  message: string;
  type?: 'success' | 'warning' | 'error' | 'info';
}> = memo(function NotificationToast({ 
  title, 
  message, 
  type = 'info' 
}) {
  const icons = {
    success: <CheckCircle className="w-5 h-5 text-emerald-500" />,
    warning: <AlertCircle className="w-5 h-5 text-amber-500" />,
    error: <X className="w-5 h-5 text-red-500" />,
    info: <Info className="w-5 h-5 text-blue-500" />
  };

  return (
    <div className="flex items-start gap-3 p-4 bg-white rounded-lg shadow-lg border border-gray-100">
      {icons[type]}
      <div>
        <h4 className="font-semibold text-sm">{title}</h4>
        <p className="text-xs text-gray-500">{message}</p>
      </div>
    </div>
  );
});

/**
 * Metric card for displaying KPIs
 */
const MetricCard: React.FC<MetricCardProps> = memo(function MetricCard({ 
  title, 
  value, 
  change, 
  icon: Icon, 
  trend = 'up', 
  delay = 0 
}) {
  const animatedValue = useAnimatedValue(typeof value === 'number' ? value : 0, 2000);
  const isPositive = trend === 'up';
  
  return (
    <AnimatedCard delay={delay} className="bg-white p-6 rounded-xl border border-gray-100 hover:border-gray-200 transition-all hover:shadow-lg group">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-gray-600 font-medium">{title}</span>
        <div className="p-2 bg-gray-50 rounded-lg group-hover:bg-gray-100 transition-colors">
          <Icon className="w-4 h-4 text-gray-600" />
        </div>
      </div>
      
      <div className="mb-2">
        <span className="text-3xl font-bold tracking-tight">
          {typeof value === 'number' ? formatNumber(animatedValue) : value}
        </span>
      </div>
      
      {change && (
        <div className="flex items-center gap-1">
          {isPositive ? (
            <ArrowUpRight className="w-4 h-4 text-emerald-600" />
          ) : (
            <ArrowDownRight className="w-4 h-4 text-red-600" />
          )}
          <span className={cn(
            "text-sm font-medium",
            isPositive ? "text-emerald-600" : "text-red-600"
          )}>
            {change}
          </span>
        </div>
      )}
    </AnimatedCard>
  );
});

/**
 * API status badge component
 */
const ApiStatusBadge: React.FC<{ animated?: boolean }> = memo(function ApiStatusBadge({ 
  animated = true 
}) {
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-full">
      <div className={cn(
        "w-2 h-2 bg-emerald-500 rounded-full",
        animated && "animate-pulse"
      )} />
      <span className="text-xs font-medium text-emerald-700">Live on Official APIs</span>
    </div>
  );
});

/**
 * Trust indicators grid component
 */
const TrustIndicators: React.FC = memo(function TrustIndicators() {
  const indicators = [
    { icon: Shield, title: 'SOC 2 Type II', subtitle: 'Certified' },
    { icon: Lock, title: 'End-to-end', subtitle: 'Encrypted' },
    { icon: Database, title: 'GDPR', subtitle: 'Compliant' },
    { icon: Globe, title: '99.9%', subtitle: 'Uptime SLA' }
  ];
  
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {indicators.map((item, i) => (
        <AnimatedCard 
          key={i} 
          delay={i * 100}
          className="p-4 bg-gray-50 rounded-lg hover:bg-white hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white rounded-lg group-hover:scale-110 transition-transform">
              <item.icon className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <div className="text-sm font-semibold">{item.title}</div>
              <div className="text-xs text-gray-600">{item.subtitle}</div>
            </div>
          </div>
        </AnimatedCard>
      ))}
    </div>
  );
});

/**
 * Export menu dropdown component
 */
const ExportMenu: React.FC<ExportMenuProps> = memo(function ExportMenu({ 
  data, 
  type = 'campaigns', 
  className = '' 
}) {
  const [isOpen, setIsOpen] = useState(false);
  
  const handleExport = (format: 'csv' | 'json'): void => {
    if (format === 'csv') {
      exportToCSV(data, `qetta_${type}_${new Date().toISOString().split('T')[0]}.csv`);
    } else if (format === 'json') {
      exportToJSON(data, `qetta_${type}_${new Date().toISOString().split('T')[0]}.json`);
    }
    setIsOpen(false);
  };
  
  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "flex items-center gap-2 px-3 py-2 rounded-lg transition-colors",
          "text-gray-600 hover:bg-gray-100",
          className
        )}
        aria-label="Export data"
        aria-expanded={isOpen}
        aria-haspopup="menu"
      >
        <Download className="w-5 h-5" />
        <span>Export data</span>
        <ChevronDown className="w-4 h-4" />
      </button>
      
      {isOpen && (
        <div className="absolute z-20 mt-1 right-0 w-48 bg-white rounded-lg shadow-lg border border-gray-100 overflow-hidden">
          <ul role="menu">
            <li role="menuitem">
              <button 
                className="w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors"
                onClick={() => handleExport('csv')}
              >
                Export to CSV
              </button>
            </li>
            <li role="menuitem">
              <button 
                className="w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors"
                onClick={() => handleExport('json')}
              >
                Export to JSON
              </button>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
});

// ========== CHART COMPONENTS ==========
/**
 * Performance chart component
 */
const PerformanceChart: React.FC<ChartProps> = memo(function PerformanceChart({ 
  data, 
  type = 'area', 
  height = 300 
}) {
  // Memoize chart types to prevent recreating on every render
  const chartTypes = useMemo(() => ({
    area: (
      <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#10B981" stopOpacity={0.8} />
            <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis 
          dataKey="name" 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#6B7280' }}
        />
        <YAxis 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#6B7280' }}
        />
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'white', 
            border: 'none', 
            borderRadius: '0.5rem', 
            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
            color: '#111827'
          }}
          itemStyle={{ color: '#10B981' }}
        />
        <Area type="monotone" dataKey="revenue" stroke="#10B981" fillOpacity={1} fill="url(#colorRevenue)" />
      </AreaChart>
    ),
    bar: (
      <BarChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <XAxis 
          dataKey="name" 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#6B7280' }}
        />
        <YAxis 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#6B7280' }}
        />
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'white', 
            border: 'none', 
            borderRadius: '0.5rem', 
            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
            color: '#111827'
          }}
          itemStyle={{ color: '#6366F1' }}
        />
        <Bar dataKey="revenue" fill="#6366F1" radius={[4, 4, 0, 0]} />
      </BarChart>
    ),
    line: (
      <LineChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <XAxis 
          dataKey="name" 
          axisLine={false} 
          tickLine={false}
          tick={{ fill: '#6B7280' }}
        />
        <YAxis 
          axisLine={false} 
          tickLine={false}
          tick={{ fill: '#6B7280' }}
        />
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'white', 
            border: 'none', 
            borderRadius: '0.5rem', 
            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
            color: '#111827'
          }}
          itemStyle={{ color: '#111827' }}
        />
        <Line 
          type="monotone" 
          dataKey="revenue" 
          stroke="#000" 
          strokeWidth={2} 
          dot={{ r: 3, fill: "#000" }} 
          activeDot={{ r: 5 }} 
        />
      </LineChart>
    )
  }), [data]);

  return (
    <div className="bg-white p-5 rounded-xl border border-gray-100">
      <div className="mb-6">
        <h3 className="text-lg font-semibold">Performance</h3>
        <p className="text-sm text-gray-500">Revenue generated over time</p>
      </div>
      <ResponsiveContainer width="100%" height={height}>
        {chartTypes[type]}
      </ResponsiveContainer>
    </div>
  );
});

/**
 * Campaign comparison chart component
 */
const ComparisonChart: React.FC<Omit<ChartProps, 'type'>> = memo(function ComparisonChart({ 
  data, 
  height = 300 
}) {
  return (
    <div className="bg-white p-5 rounded-xl border border-gray-100">
      <div className="mb-6">
        <h3 className="text-lg font-semibold">Campaign Comparison</h3>
        <p className="text-sm text-gray-500">ROI across different campaigns</p>
      </div>
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} layout="vertical" margin={{ top: 10, right: 30, left: 50, bottom: 0 }}>
          <XAxis 
            type="number" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#6B7280' }}
          />
          <YAxis 
            dataKey="name" 
            type="category" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#6B7280' }}
          />
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E5E7EB" />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: 'white', 
              border: 'none', 
              borderRadius: '0.5rem', 
              boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
              color: '#111827'
            }}
          />
          <Legend 
            formatter={(value) => (
              <span style={{ color: '#4B5563' }}>
                {value === 'expected' ? 'Expected' : 'Actual'}
              </span>
            )}
          />
          <Bar dataKey="expected" fill="#94A3B8" name="Expected" radius={[0, 4, 4, 0]} />
          <Bar dataKey="actual" fill="#10B981" name="Actual" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
});

// ========== NAVIGATION ==========
/**
 * Main navigation component
 */
const Navigation: React.FC<NavigationProps> = memo(function Navigation({ 
  viewport, 
  activeView, 
  setActiveView 
}) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { showNotification } = useContext(QettaContext);
  
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const handleNavClick = (view: string): void => {
    setActiveView(view);
    setIsMobileMenuOpen(false);
    
    if (view === 'demo') {
      showNotification('Demo Mode Activated', 'Choose your preferred interface to explore QETTA', 'success');
    }
  };
  
  return (
    <>
      <nav className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled 
          ? "bg-white/95 backdrop-blur-md shadow-sm" 
          : "bg-white/80 backdrop-blur-sm",
        "border-b border-gray-100"
      )}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <button 
                onClick={() => handleNavClick('landing')}
                className="font-bold text-xl hover:scale-105 transition-transform"
                aria-label="Home"
              >
                QETTA
              </button>
              
              {!viewport.isMobile && (
                <div className="flex items-center gap-1">
                  {['Product', 'Pricing', 'Documentation', 'Compliance'].map(item => (
                    <button
                      key={item}
                      className="px-3 py-2 text-sm text-gray-600 hover:text-black hover:bg-gray-50 rounded-lg transition-all"
                      onClick={() => showNotification('Coming Soon', `${item} section is under development`, 'info')}
                      aria-label={item}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              {viewport.isMobile ? (
                <button 
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
                  aria-expanded={isMobileMenuOpen}
                >
                  {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
              ) : (
                <>
                  <button 
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    onClick={() => showNotification('Search', 'Search functionality coming soon', 'info')}
                    aria-label="Search"
                  >
                    <Search className="w-5 h-5 text-gray-600" />
                  </button>
                  <button 
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative"
                    onClick={() => showNotification('Notifications', 'You have 3 unread notifications', 'info')}
                    aria-label="Notifications"
                  >
                    <Bell className="w-5 h-5 text-gray-600" />
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
                  </button>
                  <PulseButton 
                    onClick={() => handleNavClick('demo')}
                    className="px-4 py-2 text-sm rounded-lg"
                  >
                    Start free trial
                  </PulseButton>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>
      
      {/* Mobile Menu Overlay */}
      {viewport.isMobile && (
        <div 
          className={cn(
            "fixed inset-0 z-40 transition-all duration-300",
            isMobileMenuOpen 
              ? "opacity-100 pointer-events-auto" 
              : "opacity-0 pointer-events-none"
          )}
          aria-hidden={!isMobileMenuOpen}
        >
          <div 
            className="absolute inset-0 bg-black/20 backdrop-blur-sm"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          <div className={cn(
            "absolute right-0 top-16 bottom-0 w-80 bg-white shadow-2xl transition-transform duration-300",
            isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
          )}>
            <div className="p-6 space-y-1">
              {['Product', 'Pricing', 'Documentation', 'Compliance'].map(item => (
                <button 
                  key={item} 
                  className="block w-full text-left px-4 py-3 text-lg hover:bg-gray-50 rounded-lg transition-colors"
                  onClick={() => {
                    showNotification('Coming Soon', `${item} section is under development`, 'info');
                    setIsMobileMenuOpen(false);
                  }}
                >
                  {item}
                </button>
              ))}
              <hr className="my-4 border-gray-200" />
              <button 
                className="block w-full text-left px-4 py-3 text-lg hover:bg-gray-50 rounded-lg"
                onClick={() => {
                  showNotification('Sign In', 'Authentication system is in demo mode', 'info');
                  setIsMobileMenuOpen(false);
                }}
              >
                Sign in
              </button>
              <PulseButton 
                onClick={() => handleNavClick('demo')}
                className="w-full py-3 rounded-lg mt-2"
              >
                Start free trial
              </PulseButton>
            </div>
          </div>
        </div>
      )}
    </>
  );
});

// ========== LANDING PAGE ==========
interface LandingPageProps {
  viewport: Viewport;
  setActiveView: (view: string) => void;
  animationSpeed?: number;
}

const LandingPage: React.FC<LandingPageProps> = memo(function LandingPage({ 
  viewport, 
  setActiveView, 
  animationSpeed = 1 
}) {
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { showNotification } = useContext(QettaContext);
  
  const handleEmailSubmit = async (): Promise<void> => {
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setEmailError('Please enter a valid email');
      return;
    }
    
    setIsSubmitting(true);
    setEmailError('');
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setEmail('');
    showNotification('Success', 'Your trial request has been submitted!', 'success');
  };
  
  const features = useMemo(() => [
    { icon: Zap, title: 'Real-time Data', desc: 'Live metrics from official APIs' },
    { icon: Shield, title: 'Compliant', desc: '100% platform policy adherent' },
    { icon: DollarSign, title: 'Instant Settlement', desc: 'T+0 creator payouts' },
    { icon: BarChart3, title: 'Advanced Analytics', desc: 'ML-powered insights' }
  ], []);
  
  return (
    <div className="min-h-screen bg-white">
      <Navigation viewport={viewport} activeView="landing" setActiveView={setActiveView} />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-emerald-50 rounded-full blur-3xl opacity-30 animate-pulse" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-teal-50 rounded-full blur-3xl opacity-30 animate-pulse" style={{ animationDelay: '1s' }} />
        </div>
        
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl">
            <AnimatedCard delay={0} speed={animationSpeed}>
              <ApiStatusBadge />
            </AnimatedCard>
            
            <AnimatedCard delay={100} speed={animationSpeed}>
              <h1 className={cn(
                "font-normal leading-tight tracking-tight mt-8 mb-6",
                viewport.isMobile ? "text-4xl" : "text-5xl md:text-6xl lg:text-7xl"
              )}>
                Evidence-based
                <br />
                influencer
                <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-400 to-gray-600">
                  intelligence.
                </span>
              </h1>
            </AnimatedCard>
            
            <AnimatedCard delay={200} speed={animationSpeed}>
              <p className="text-lg text-gray-600 max-w-2xl mb-8 leading-relaxed">
                Official API integration. Selective event tracking. T+0 settlement.
                Built for teams that need both speed and compliance.
              </p>
            </AnimatedCard>
            
            <AnimatedCard delay={300} speed={animationSpeed}>
              <div className="flex flex-col sm:flex-row gap-4">
                <PulseButton 
                  onClick={() => setActiveView('demo')}
                  className="px-6 py-3 rounded-lg flex items-center gap-2"
                >
                  Start free trial
                  <ArrowRight className="w-4 h-4" />
                </PulseButton>
                <PulseButton 
                  variant="secondary"
                  className="px-6 py-3 rounded-lg"
                  onClick={() => showNotification('Documentation', 'Documentation section is coming soon', 'info')}
                >
                  View documentation
                </PulseButton>
              </div>
            </AnimatedCard>
            
            <AnimatedCard delay={400} speed={animationSpeed}>
              <div className="mt-12 flex flex-wrap items-center gap-6 text-sm text-gray-500">
                {['SOC 2 Type II', 'GDPR Compliant', '99.9% SLA'].map((item, i) => (
                  <div 
                    key={item} 
                    className="flex items-center gap-2 group cursor-pointer"
                    onClick={() => showNotification('Compliance', `QETTA is ${item} certified and compliant`, 'info')}
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
                    <span className="group-hover:text-gray-700 transition-colors">{item}</span>
                  </div>
                ))}
              </div>
            </AnimatedCard>
          </div>
        </div>
      </section>
      
      {/* Metrics Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto">
          <AnimatedCard delay={0} speed={animationSpeed}>
            <h2 className="text-3xl font-normal text-center mb-12">
              Trusted by 500+ brands worldwide
            </h2>
          </AnimatedCard>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <MetricCard 
              title="Average ROI" 
              value="3.2×" 
              change="+0.5 vs industry" 
              icon={TrendingUp}
              trend="up"
              delay={100 * animationSpeed}
            />
            <MetricCard 
              title="Settlement Speed" 
              value="T+0" 
              change="30× faster" 
              icon={Clock}
              trend="up"
              delay={200 * animationSpeed}
            />
            <MetricCard 
              title="Cost Reduction" 
              value="99%" 
              change="vs manual" 
              icon={DollarSign}
              trend="up"
              delay={300 * animationSpeed}
            />
            <MetricCard 
              title="False Positives" 
              value="<2%" 
              change="-18% YoY" 
              icon={Shield}
              trend="up"
              delay={400 * animationSpeed}
            />
          </div>
        </div>
      </section>
      
      {/* Features Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <AnimatedCard speed={animationSpeed}>
            <h2 className="text-3xl font-normal text-center mb-4">
              Built for modern marketing teams
            </h2>
            <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">
              Everything you need to run evidence-based influencer campaigns at scale
            </p>
          </AnimatedCard>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <AnimatedCard 
                key={i} 
                delay={i * 100}
                speed={animationSpeed}
                className="p-6 bg-white border border-gray-100 rounded-xl hover:border-emerald-200 hover:shadow-xl transition-all group cursor-pointer"
                onClick={() => showNotification(feature.title, feature.desc, 'info')}
              >
                <div className="mb-4 p-3 bg-gray-50 rounded-lg inline-block group-hover:bg-emerald-50 transition-colors">
                  <feature.icon className="w-6 h-6 text-gray-700 group-hover:text-emerald-600 transition-colors" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-600">{feature.desc}</p>
              </AnimatedCard>
            ))}
          </div>
        </div>
      </section>
      
      {/* Trust Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <AnimatedCard speed={animationSpeed}>
            <h2 className="text-3xl font-normal text-center mb-12">
              Enterprise-grade security & compliance
            </h2>
          </AnimatedCard>
          <TrustIndicators />
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-black text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black" />
        
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <AnimatedCard speed={animationSpeed}>
            <h2 className="text-3xl md:text-4xl font-normal mb-6">
              Ready to scale with confidence?
            </h2>
            <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto">
              Join 500+ brands using QETTA for evidence-based influencer marketing.
              Free trial. No credit card. 2-minute setup.
            </p>
          </AnimatedCard>
          
          <AnimatedCard delay={100} speed={animationSpeed}>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <div className="flex-1 relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleEmailSubmit()}
                  placeholder="work@company.com"
                  className={cn(
                    "w-full px-4 py-3 bg-white/10 backdrop-blur-sm border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all",
                    emailError ? "border-red-500" : "border-gray-700"
                  )}
                  aria-label="Email"
                  aria-invalid={!!emailError}
                />
                {emailError && (
                  <span className="absolute -bottom-6 left-0 text-xs text-red-400" role="alert">
                    {emailError}
                  </span>
                )}
              </div>
              <PulseButton
                variant="emerald"
                onClick={handleEmailSubmit}
                disabled={isSubmitting}
                className="px-8 py-3 rounded-lg flex items-center gap-2 justify-center"
                aria-label={isSubmitting ? "Loading..." : "Start free trial"}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Loading...</span>
                  </>
                ) : (
                  <>
                    <span>Start free trial</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </PulseButton>
            </div>
          </AnimatedCard>
        </div>
      </section>
    </div>
  );
});

// ========== BRAND DASHBOARD ==========
interface BrandDashboardProps {
  viewport: Viewport;
  animationSpeed?: number;
}

const BrandDashboard: React.FC<BrandDashboardProps> = memo(function BrandDashboard({ 
  viewport, 
  animationSpeed = 1 
}) {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [showFilters, setShowFilters] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const { showNotification } = useContext(QettaContext);
  
  // Memoize campaign data to prevent recreation on each render
  const campaigns = useMemo<Campaign[]>(() => [
    { id: 1, name: 'Summer Collection 2024', creators: 23, gmv: 12847300, roi: 3.8, risk: 0.12, status: 'active' },
    { id: 2, name: 'Flash Sale Weekend', creators: 45, gmv: 8923100, roi: 2.9, risk: 0.08, status: 'active' },
    { id: 3, name: 'New Product Launch', creators: 12, gmv: 4187200, roi: 4.2, risk: 0.15, status: 'review' }
  ], []);
  
  // Mock chart data
  const performanceData = useMemo(() => [
    { name: 'Jan', revenue: 4000 },
    { name: 'Feb', revenue: 3000 },
    { name: 'Mar', revenue: 5000 },
    { name: 'Apr', revenue: 7000 },
    { name: 'May', revenue: 5000 },
    { name: 'Jun', revenue: 8000 },
    { name: 'Jul', revenue: 12000 },
  ], []);

  const campaignComparisonData = useMemo(() => [
    { name: 'Summer Collection', expected: 3.0, actual: 3.8 },
    { name: 'Flash Sale', expected: 2.5, actual: 2.9 },
    { name: 'Product Launch', expected: 3.5, actual: 4.2 },
  ], []);

  // Memoized handlers to prevent recreating functions on each render
  const handleCreateCampaign = useCallback(() => {
    showNotification('New Campaign', 'Campaign creation wizard launched', 'success');
  }, [showNotification]);

  const handleCampaignClick = useCallback((campaign: Campaign) => {
    showNotification(
      'Campaign Details', 
      `Viewing details for "${campaign.name}" with ${campaign.creators} creators`, 
      'info'
    );
  }, [showNotification]);
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Nav */}
      <nav className="bg-white border-b sticky top-0 z-40">
        <div className="px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="font-bold text-lg">QETTA</div>
            <div className="flex items-center gap-1">
              {['Campaigns', 'Analytics', 'Settlement', 'Compliance'].map(item => (
                <button 
                  key={item} 
                  className={cn(
                    "px-3 py-1.5 text-sm hover:bg-gray-50 rounded-lg transition-all",
                    activeTab === item.toLowerCase() 
                      ? "text-black font-medium" 
                      : "text-gray-600"
                  )}
                  onClick={() => {
                    setActiveTab(item.toLowerCase());
                    showNotification('Navigation', `Switched to ${item} view`, 'info');
                  }}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <ApiStatusBadge />
            <button 
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              onClick={() => showNotification('Notifications', 'You have 2 new compliance alerts', 'info')}
            >
              <Bell className="w-5 h-5 text-gray-600" />
            </button>
            <button 
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              onClick={() => showNotification('Settings', 'Account settings panel opened', 'info')}
            >
              <Settings className="w-5 h-5 text-gray-600" />
            </button>
            <div 
              className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full cursor-pointer"
              onClick={() => showNotification('Profile', 'User profile: Marketing Manager', 'info')}
            />
          </div>
        </div>
      </nav>
      
      {/* Main Content */}
      <div className="p-6">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold mb-2">Dashboard</h1>
            <p className="text-gray-600">Monitor your influencer marketing performance</p>
          </div>
          <ExportMenu data={campaigns} type="campaigns" />
        </div>
        
        {/* Period Selector */}
        <div className="flex flex-wrap items-center gap-2 mb-6">
          {['day', 'week', 'month', 'year'].map(period => (
            <button
              key={period}
              onClick={() => {
                setSelectedPeriod(period);
                showNotification('Time Period', `Viewing data for: ${period}`, 'info');
              }}
              className={cn(
                "px-4 py-2 text-sm font-medium rounded-lg transition-all capitalize",
                selectedPeriod === period
                  ? "bg-black text-white"
                  : "text-gray-600 hover:text-black hover:bg-gray-100"
              )}
            >
              {period}
            </button>
          ))}
        </div>
        
        {/* Metrics Grid */}
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-4 mb-8">
          <MetricCard 
            title="GMV This Month" 
            value={48720000} 
            change="+32%" 
            icon={TrendingUp}
            trend="up"
          />
          <MetricCard 
            title="Active Creators" 
            value={127} 
            change="+12" 
            icon={Users}
            trend="up"
          />
          <MetricCard 
            title="Avg. ROI" 
            value="3.2×" 
            change="+0.3" 
            icon={BarChart3}
            trend="up"
          />
          <MetricCard 
            title="Pending Settlements" 
            value={7} 
            change="-5" 
            icon={Clock}
            trend="up"
          />
        </div>

        {/* Analytics Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <AnimatedCard delay={100} speed={animationSpeed}>
            <PerformanceChart data={performanceData} type="area" />
          </AnimatedCard>
          
          <AnimatedCard delay={200} speed={animationSpeed}>
            <ComparisonChart data={campaignComparisonData} />
          </AnimatedCard>
        </div>
        
        {/* Campaigns Table */}
        <AnimatedCard delay={300} speed={animationSpeed}>
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <h2 className="font-semibold">Active Campaigns</h2>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setShowFilters(!showFilters)}
                  className="px-3 py-1.5 text-sm text-gray-600 hover:text-black border border-gray-200 rounded-lg hover:bg-gray-50 transition-all flex items-center gap-2"
                  aria-expanded={showFilters}
                  aria-controls="filters-panel"
                >
                  <Filter className="w-4 h-4" />
                  Filters
                </button>
                <PulseButton 
                  className="px-3 py-1.5 text-sm rounded-lg"
                  onClick={handleCreateCampaign}
                >
                  New Campaign
                </PulseButton>
              </div>
            </div>
            
            {showFilters && (
              <div id="filters-panel" className="p-4 bg-gray-50 border-b border-gray-200">
                <div className="flex flex-col sm:flex-row gap-4">
                  <input 
                    type="text" 
                    placeholder="Search campaigns..."
                    className="flex-1 px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    aria-label="Search campaigns"
                  />
                  <select className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option>All Status</option>
                    <option>Active</option>
                    <option>Review</option>
                    <option>Completed</option>
                  </select>
                  <button className="px-3 py-2 text-sm bg-black text-white rounded-lg">
                    Apply
                  </button>
                </div>
              </div>
            )}
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  <tr>
                    <th className="text-left p-4">Campaign</th>
                    <th className="text-left p-4">Creators</th>
                    <th className="text-right p-4">GMV</th>
                    <th className="text-right p-4">ROI</th>
                    <th className="text-right p-4">Risk</th>
                    <th className="text-left p-4">Status</th>
                    <th className="text-center p-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {campaigns.map((campaign) => (
                    <tr 
                      key={campaign.id} 
                      className="hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => handleCampaignClick(campaign)}
                    >
                      <td className="p-4">
                        <div className="font-medium">{campaign.name}</div>
                        <div className="text-xs text-gray-500 mt-1">ID: {campaign.id}</div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{campaign.creators}</span>
                          <span className="text-xs text-gray-500">creators</span>
                        </div>
                      </td>
                      <td className="p-4 text-right font-mono text-sm">
                        {formatCurrency(campaign.gmv)}
                      </td>
                      <td className="p-4 text-right">
                        <span className="font-mono text-sm font-medium">{campaign.roi}×</span>
                      </td>
                      <td className="p-4 text-right">
                        <span className={cn(
                          "px-2 py-1 text-xs rounded-full font-mono inline-flex items-center gap-1",
                          campaign.risk < 0.1 ? "bg-emerald-50 text-emerald-700" :
                          campaign.risk < 0.2 ? "bg-amber-50 text-amber-700" :
                          "bg-red-50 text-red-700"
                        )}>
                          <span className={cn(
                            "w-1.5 h-1.5 rounded-full",
                            campaign.risk < 0.1 ? "bg-emerald-500" :
                            campaign.risk < 0.2 ? "bg-amber-500" :
                            "bg-red-500"
                          )} />
                          {campaign.risk.toFixed(2)}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className={cn(
                          "px-2.5 py-1 text-xs rounded-full font-medium",
                          campaign.status === 'active' 
                            ? "bg-emerald-50 text-emerald-700" 
                            : "bg-amber-50 text-amber-700"
                        )}>
                          {campaign.status}
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <button 
                          className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCampaignClick(campaign);
                          }}
                          aria-label={`View ${campaign.name} details`}
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </AnimatedCard>
      </div>
    </div>
  );
});

// ========== CONTENT FEED COMPONENT ==========
/**
 * Content feed item component for social posts
 */
const ContentFeedItem: React.FC<ContentFeedItemProps> = memo(function ContentFeedItem({ 
  post, 
  onLike, 
  onComment 
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
      {/* Post Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full" />
          <div>
            <div className="font-medium text-sm">{post.author}</div>
            <div className="text-xs text-gray-500">{post.time}</div>
          </div>
        </div>
        <button 
          className="p-1.5 hover:bg-gray-100 rounded-full transition-colors"
          aria-label="Post options"
        >
          <ChevronDown className="w-4 h-4" />
        </button>
      </div>
      
      {/* Post Image */}
      <div className="relative aspect-[4/3] bg-gray-100">
        <ImageWithFallback 
          src={post.image}
          alt={`Post by ${post.author}`} 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Post Actions */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-4">
            <button 
              className={cn(
                "flex items-center gap-1.5",
                post.liked ? "text-red-500" : "text-gray-600 hover:text-red-500"
              )}
              onClick={() => onLike(post.id)}
              aria-label={post.liked ? "Unlike post" : "Like post"}
              aria-pressed={post.liked}
            >
              <Heart className="w-5 h-5" fill={post.liked ? "#EF4444" : "none"} />
              <span className="text-sm font-medium">{post.likes}</span>
            </button>
            <button 
              className="flex items-center gap-1.5 text-gray-600 hover:text-black"
              onClick={() => onComment(post.id)}
              aria-label="Comment on post"
            >
              <MessageSquare className="w-5 h-5" />
              <span className="text-sm font-medium">{post.comments}</span>
            </button>
            <button 
              className="flex items-center gap-1.5 text-gray-600 hover:text-black"
              aria-label="Share post"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
          <button 
            className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-600 hover:text-emerald-600"
            aria-label="Award post"
          >
            <Award className="w-5 h-5" />
          </button>
        </div>
        
        {/* Caption */}
        <p className="text-sm text-gray-700 mb-1">
          <span className="font-medium">{post.author}</span> {post.caption}
        </p>
        <button 
          className="text-xs text-gray-500 hover:text-gray-700"
          aria-label={`View all ${post.comments} comments`}
        >
          View all {post.comments} comments
        </button>
      </div>
    </div>
  );
});

// ========== CREATOR DASHBOARD ==========
interface CreatorDashboardProps {
  animationSpeed?: number;
}

const CreatorDashboard: React.FC<CreatorDashboardProps> = memo(function CreatorDashboard({ 
  animationSpeed = 1 
}) {
  const [activeTab, setActiveTab] = useState('home');
  const { showNotification } = useContext(QettaContext);
  const parentRef = useRef<HTMLElement>(null);
  
  // Creator dashboard data
  const earnings = {
    month: 2847300,
    pending: 487200,
    available: 2360100
  };
  
  const transactions = useMemo<Transaction[]>(() => [
    { id: 1, brand: 'Bloom Beauty', amount: 487200, status: 'completed', date: '2h ago', change: '+23%' },
    { id: 2, brand: 'StyleCo', amount: 312400, status: 'processing', date: '5h ago', change: '+15%' },
    { id: 3, brand: 'FitGear', amount: 198700, status: 'completed', date: '1d ago', change: '+8%' }
  ], []);
  
  const bottomNavItems = useMemo(() => [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'earnings', icon: DollarSign, label: 'Earnings' },
    { id: 'profile', icon: Users, label: 'Profile' }
  ], []);

  // Sample content feed data
  const [feedPosts, setFeedPosts] = useState<Post[]>([
    {
      id: 1,
      author: 'StyleInfluencer',
      time: '35 minutes ago',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      caption: 'Sharing my latest collab with Bloom Beauty! Loving their new summer collection. #ad',
      likes: 482,
      comments: 57,
      liked: false
    },
    {
      id: 2,
      author: 'TravelWithMe',
      time: '2 hours ago',
      image: 'https://images.unsplash.com/photo-1527631746610-bca00a040d60?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      caption: 'Exploring new places with my favorite FitGear backpack. Perfect for day hikes!',
      likes: 823,
      comments: 91,
      liked: true
    },
    {
      id: 3,
      author: 'FoodieCreator',
      time: '5 hours ago',
      image: 'https://images.unsplash.com/photo-1484723091739-30a097e8f929?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      caption: 'Making breakfast more exciting with StyleCo new kitchen collection.',
      likes: 634,
      comments: 42,
      liked: false
    }
  ]);

  // Generate more mock feed posts for virtualization demo
  const allFeedPosts = useMemo(() => {
    const basePosts = [...feedPosts];
    const additionalPosts = [];
    
    for (let i = 4; i <= 50; i++) {
      const basePost = basePosts[i % 3];
      additionalPosts.push({
        ...basePost,
        id: i,
        time: `${i} hours ago`,
        likes: Math.floor(Math.random() * 1000) + 100,
        comments: Math.floor(Math.random() * 100) + 10,
        liked: Math.random() > 0.5
      });
    }
    
    return [...basePosts, ...additionalPosts];
  }, [feedPosts]);

  // Virtualization for feed posts
  const virtualizer = useVirtualizer({
    count: activeTab === 'home' ? allFeedPosts.length : 0,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 480, // Estimated height of each post
    overscan: 3
  });

  // Event handlers
  const handleLike = useCallback((postId: number) => {
    setFeedPosts(posts => posts.map(post => {
      if (post.id === postId) {
        return { 
          ...post, 
          liked: !post.liked, 
          likes: post.liked ? post.likes - 1 : post.likes + 1 
        };
      }
      return post;
    }));
    
    showNotification('Interaction', 'Post like status updated', 'success');
  }, [showNotification]);

  const handleComment = useCallback((postId: number) => {
    showNotification('Comments', 'Comment section opened', 'info');
  }, [showNotification]);

  const handleAction = useCallback((action: string) => {
    if (action === 'request-payment') {
      showNotification('Payment Request', 'T+0 settlement requested successfully', 'success');
    } else if (action === 'add-bank') {
      showNotification('Bank Details', 'Bank account setup wizard launched', 'info');
    }
  }, [showNotification]);

  const handleTabChange = useCallback((tabId: string) => {
    setActiveTab(tabId);
    const tabLabel = bottomNavItems.find(item => item.id === tabId)?.label || tabId;
    showNotification('Navigation', `Switched to ${tabLabel} tab`, 'info');
  }, [bottomNavItems, showNotification]);
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="font-bold text-lg">QETTA</div>
          <div className="flex items-center gap-3">
            <button 
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              onClick={() => showNotification('Notifications', 'You have 4 new notifications', 'info')}
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
            </button>
            <div 
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => showNotification('Balance', 'Your available balance is ready for withdrawal', 'info')}
              aria-label="Account balance"
            >
              <span className="text-sm font-medium">{formatCurrency(earnings.available)}</span>
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full" />
            </div>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="pb-20" ref={parentRef}>
        {activeTab === 'home' && (
          <>
            {/* Earnings Overview */}
            <div className="p-4">
              <AnimatedCard speed={animationSpeed}>
                <div className="bg-gradient-to-br from-black to-gray-900 text-white rounded-2xl p-6 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/20 rounded-full blur-3xl" />
                  <div className="relative z-10">
                    <div className="text-sm opacity-80 mb-1">Total Earnings</div>
                    <div className="text-3xl font-bold mb-4">{formatCurrency(earnings.month)}</div>
                    <div className="flex items-center gap-4">
                      <div>
                        <div className="text-xs opacity-70">Available</div>
                        <div className="font-semibold">{formatCurrency(earnings.available)}</div>
                      </div>
                      <div>
                        <div className="text-xs opacity-70">Pending</div>
                        <div className="font-semibold">{formatCurrency(earnings.pending)}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </AnimatedCard>
              
              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <AnimatedCard delay={100} speed={animationSpeed}>
                  <PulseButton 
                    className="w-full p-4 rounded-xl flex flex-col items-center gap-2"
                    onClick={() => handleAction('request-payment')}
                  >
                    <Sparkles className="w-6 h-6" />
                    <span className="text-sm font-medium">Request T+0</span>
                  </PulseButton>
                </AnimatedCard>
                
                <AnimatedCard delay={200} speed={animationSpeed}>
                  <PulseButton 
                    variant="secondary" 
                    className="w-full p-4 rounded-xl flex flex-col items-center gap-2"
                    onClick={() => handleAction('add-bank')}
                  >
                    <CreditCard className="w-6 h-6" />
                    <span className="text-sm font-medium">Add Bank</span>
                  </PulseButton>
                </AnimatedCard>
              </div>
            </div>

            {/* Content Feed Section */}
            <div className="mt-6 px-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Your Content</h3>
                <button 
                  className="text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1"
                  onClick={() => showNotification('Content Creation', 'Create new post wizard launched', 'info')}
                >
                  <Sparkles className="w-4 h-4" />
                  Create Post
                </button>
              </div>
              
              <div 
                className="space-y-6 mb-6"
                style={{
                  height: `${virtualizer.getTotalSize()}px`,
                  position: 'relative',
                  width: '100%',
                }}
              >
                {virtualizer.getVirtualItems().map((virtualItem) => (
                  <AnimatedCard 
                    key={virtualItem.key} 
                    delay={300 + virtualItem.index * 100} 
                    speed={animationSpeed}
                    className="absolute top-0 left-0 w-full"
                    style={{
                      transform: `translateY(${virtualItem.start}px)`,
                    }}
                  >
                    <ContentFeedItem 
                      post={allFeedPosts[virtualItem.index]}
                      onLike={handleLike}
                      onComment={handleComment}
                    />
                  </AnimatedCard>
                ))}
              </div>
            </div>
            
            {/* Recent Transactions */}
            <div className="mt-6 px-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Recent Settlements</h3>
                <button 
                  className="text-sm text-emerald-600 hover:text-emerald-700 font-medium"
                  onClick={() => showNotification('Settlements', 'Viewing all settlement history', 'info')}
                >
                  View all
                </button>
              </div>
              
              <div className="space-y-3">
                {transactions.map((transaction, i) => (
                  <AnimatedCard key={transaction.id} delay={i * 100} speed={animationSpeed}>
                    <div 
                      className="bg-white p-4 rounded-xl border border-gray-100 hover:border-gray-200 transition-all hover:shadow-md cursor-pointer"
                      onClick={() => showNotification(
                        'Transaction Details', 
                        `Viewing settlement from ${transaction.brand} for ${formatCurrency(transaction.amount)}`, 
                        'info'
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                            <DollarSign className="w-5 h-5 text-gray-600" />
                          </div>
                          <div>
                            <div className="font-medium">{transaction.brand}</div>
                            <div className="text-xs text-gray-500">{transaction.date}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">{formatCurrency(transaction.amount)}</div>
                          <div className={cn(
                            "text-xs flex items-center gap-1 justify-end",
                            transaction.status === 'completed' ? 'text-emerald-600' : 'text-amber-600'
                          )}>
                            {transaction.status === 'completed' ? (
                              <CheckCircle className="w-3 h-3" />
                            ) : (
                              <Clock className="w-3 h-3" />
                            )}
                            {transaction.status}
                          </div>
                        </div>
                      </div>
                    </div>
                  </AnimatedCard>
                ))}
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'analytics' && (
          <div className="p-4">
            <AnimatedCard speed={animationSpeed}>
              <h3 className="text-lg font-semibold mb-4">Performance Analytics</h3>
              <div className="bg-white rounded-xl border border-gray-100 p-4 mb-6">
                <PerformanceChart 
                  data={[
                    { name: 'Mon', revenue: 1200 },
                    { name: 'Tue', revenue: 1800 },
                    { name: 'Wed', revenue: 1500 },
                    { name: 'Thu', revenue: 2200 },
                    { name: 'Fri', revenue: 2600 },
                    { name: 'Sat', revenue: 3100 },
                    { name: 'Sun', revenue: 2400 },
                  ]} 
                  type="line" 
                />
              </div>
            </AnimatedCard>
            
            <AnimatedCard delay={200} speed={animationSpeed}>
              <h3 className="text-lg font-semibold mb-4">Audience Insights</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-xl border border-gray-100">
                  <div className="text-sm text-gray-600 mb-1">Engagement Rate</div>
                  <div className="text-3xl font-bold">4.8%</div>
                  <div className="flex items-center gap-1 mt-1 text-emerald-600 text-xs">
                    <ArrowUpRight className="w-3 h-3" />
                    <span>+0.5% vs last week</span>
                  </div>
                </div>
                
                <div className="bg-white p-4 rounded-xl border border-gray-100">
                  <div className="text-sm text-gray-600 mb-1">Follower Growth</div>
                  <div className="text-3xl font-bold">+1,243</div>
                  <div className="flex items-center gap-1 mt-1 text-emerald-600 text-xs">
                    <ArrowUpRight className="w-3 h-3" />
                    <span>+12% vs last week</span>
                  </div>
                </div>
              </div>
            </AnimatedCard>
          </div>
        )}
        
        {activeTab === 'earnings' && (
          <div className="p-4">
            <AnimatedCard speed={animationSpeed}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Earnings History</h3>
                <ExportMenu data={transactions} type="earnings" />
              </div>
              <div className="bg-white rounded-xl border border-gray-100 p-4 mb-6">
                <PerformanceChart 
                  data={[
                    { name: 'Jan', revenue: 1800000 },
                    { name: 'Feb', revenue: 2200000 },
                    { name: 'Mar', revenue: 1900000 },
                    { name: 'Apr', revenue: 2500000 },
                    { name: 'May', revenue: 2700000 },
                    { name: 'Jun', revenue: 2300000 },
                    { name: 'Jul', revenue: 2847300 },
                  ]} 
                  type="bar" 
                />
              </div>
            </AnimatedCard>
            
            <AnimatedCard delay={200} speed={animationSpeed}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">All Transactions</h3>
                <div>
                  <select className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option>This Month</option>
                    <option>Last 3 Months</option>
                    <option>This Year</option>
                    <option>All Time</option>
                  </select>
                </div>
              </div>
              
              <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
                <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                  <div className="text-sm font-medium">Date</div>
                  <div className="text-sm font-medium">Amount</div>
                </div>
                
                <div className="divide-y divide-gray-100">
                  {[...Array(5)].map((_, i) => (
                    <div 
                      key={i} 
                      className="p-4 flex items-center justify-between hover:bg-gray-50 cursor-pointer"
                      onClick={() => showNotification('Transaction Details', 'Viewing detailed settlement information', 'info')}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                          <DollarSign className="w-4 h-4 text-gray-600" />
                        </div>
                        <div>
                          <div className="font-medium text-sm">
                            {['Bloom Beauty', 'StyleCo', 'FitGear', 'TechGadgets', 'EcoHome'][i]}
                          </div>
                          <div className="text-xs text-gray-500">
                            {['Jul 28, 2024', 'Jul 22, 2024', 'Jul 15, 2024', 'Jul 10, 2024', 'Jul 5, 2024'][i]}
                          </div>
                        </div>
                      </div>
                      <div className="font-semibold">
                        {formatCurrency([487200, 312400, 198700, 425600, 289300][i])}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </AnimatedCard>
          </div>
        )}
        
        {activeTab === 'profile' && (
          <div className="p-4">
            <AnimatedCard speed={animationSpeed}>
              <div className="bg-white rounded-xl border border-gray-100 p-6 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full mx-auto mb-4" />
                <h3 className="text-xl font-semibold">Fashion Creator</h3>
                <p className="text-gray-600 mb-4">@fashion_influencer</p>
                
                <div className="flex justify-center gap-4 mb-6">
                  <div className="text-center">
                    <div className="font-bold">245K</div>
                    <div className="text-xs text-gray-500">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">1.2K</div>
                    <div className="text-xs text-gray-500">Posts</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">4.8%</div>
                    <div className="text-xs text-gray-500">Engagement</div>
                  </div>
                </div>
                
                <button 
                  className="w-full py-2.5 bg-black text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
                  onClick={() => showNotification('Profile', 'Edit profile mode activated', 'info')}
                >
                  Edit Profile
                </button>
              </div>
            </AnimatedCard>
            
            <AnimatedCard delay={200} speed={animationSpeed}>
              <div className="mt-6 space-y-4">
                <div className="bg-white rounded-xl border border-gray-100 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Settings className="w-5 h-5 text-gray-600" />
                      <span className="font-medium">Account Settings</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </div>
                </div>
                
                <div className="bg-white rounded-xl border border-gray-100 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Bell className="w-5 h-5 text-gray-600" />
                      <span className="font-medium">Notification Preferences</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </div>
                </div>
                
                <div className="bg-white rounded-xl border border-gray-100 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CreditCard className="w-5 h-5 text-gray-600" />
                      <span className="font-medium">Payment Methods</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </div>
                </div>
                
                <div className="bg-white rounded-xl border border-gray-100 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Shield className="w-5 h-5 text-gray-600" />
                      <span className="font-medium">Privacy & Security</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </div>
                </div>
                
                <button 
                  className="w-full p-4 text-red-600 font-medium bg-white rounded-xl border border-gray-100 hover:bg-red-50 transition-colors text-center"
                  onClick={() => showNotification('Logout', 'You have been successfully logged out', 'info')}
                >
                  Log Out
                </button>
              </div>
            </AnimatedCard>
          </div>
        )}
      </main>
      
      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t z-10">
        <div className="grid grid-cols-4">
          {bottomNavItems.map(item => (
            <button
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={cn(
                "flex flex-col items-center justify-center gap-1 py-3 transition-all",
                activeTab === item.id ? "text-black" : "text-gray-400"
              )}
              aria-label={item.label}
              aria-current={activeTab === item.id ? 'page' : undefined}
            >
              <item.icon className={cn(
                "w-5 h-5 transition-transform",
                activeTab === item.id && "scale-110"
              )} />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
});

// ========== DEMO SELECTOR ==========
interface DemoSelectorProps {
  setActiveView: (view: string) => void;
  animationSpeed?: number;
}

const DemoSelector: React.FC<DemoSelectorProps> = memo(function DemoSelector({ 
  setActiveView, 
  animationSpeed = 1 
}) {
  const { showNotification } = useContext(QettaContext);
  
  const demos = useMemo(() => [
    {
      id: 'creator',
      icon: Smartphone,
      label: 'Mobile-first',
      title: 'Creator Dashboard',
      description: 'Track earnings, request instant payouts, view analytics',
      gradient: 'from-emerald-400 to-teal-500'
    },
    {
      id: 'brand',
      icon: Monitor,
      label: 'Desktop-first',
      title: 'Brand Dashboard',
      description: 'Manage campaigns, analyze ROI, handle compliance',
      gradient: 'from-purple-400 to-pink-500'
    },
    {
      id: 'landing',
      icon: Globe,
      label: 'Responsive',
      title: 'Marketing Site',
      description: 'Learn about QETTA, explore features, start trial',
      gradient: 'from-blue-400 to-cyan-500'
    }
  ], []);
  
  const handleDemoSelect = useCallback((id: string) => {
    setActiveView(id);
    const demo = demos.find(d => d.id === id);
    if (demo) {
      showNotification(
        'Demo Selected',
        `You are now viewing the ${demo.title}`,
        'success'
      );
    }
  }, [demos, setActiveView, showNotification]);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <AnimatedCard speed={animationSpeed}>
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Choose Your Experience</h1>
            <p className="text-gray-600 text-lg">Select your role to see the optimized interface</p>
          </div>
        </AnimatedCard>
        
        <div className="grid md:grid-cols-3 gap-6">
          {demos.map((demo, i) => (
            <AnimatedCard key={demo.id} delay={i * 100} speed={animationSpeed}>
              <button
                onClick={() => handleDemoSelect(demo.id)}
                className="relative p-6 bg-white rounded-2xl border-2 border-gray-200 hover:border-emerald-500 transition-all text-left group hover:shadow-2xl hover:-translate-y-1"
                aria-label={demo.title}
              >
                <div className="absolute top-0 right-0 w-24 h-24 opacity-10">
                  <div className={cn(
                    "w-full h-full rounded-full bg-gradient-to-br blur-2xl",
                    demo.gradient
                  )} />
                </div>
                
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl bg-gradient-to-br text-white",
                      demo.gradient
                    )}>
                      <demo.icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full font-medium">
                      {demo.label}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold mb-2 group-hover:text-emerald-600 transition-colors">
                    {demo.title}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {demo.description}
                  </p>
                </div>
              </button>
            </AnimatedCard>
          ))}
        </div>
        
        <AnimatedCard delay={400} speed={animationSpeed}>
          <div className="mt-12 text-center">
            <button
              onClick={() => setActiveView('landing')}
              className="text-sm text-gray-600 hover:text-black transition-colors"
              aria-label="Back to home"
            >
              ← Back to home
            </button>
          </div>
        </AnimatedCard>
      </div>
    </div>
  );
});

// ========== MAIN COMPONENT ==========
interface QettaPlatformProps {
  initialView?: 'landing' | 'demo' | 'creator' | 'brand';
  animationSpeed?: number;
}

/**
 * QETTA Platform - Main component
 * 
 * A comprehensive influencer marketing platform with multiple views:
 * - Landing page
 * - Demo selector
 * - Creator dashboard
 * - Brand dashboard
 */
const QettaPlatform: React.FC<QettaPlatformProps> = function QettaPlatform({ 
  initialView = 'landing', 
  animationSpeed = 1 
}) {
  const [activeView, setActiveView] = useState(initialView);
  const viewport = useViewport();
  const { showNotification } = useNotifications();

  // Effect to set the initial view based on prop
  useEffect(() => {
    setActiveView(initialView);
  }, [initialView]);

  // Apply animation speed to all animations
  useEffect(() => {
    document.documentElement.style.setProperty('--animation-speed-multiplier', (1 / animationSpeed).toString());
  }, [animationSpeed]);
  
  return (
    <ErrorBoundary>
      <QettaContext.Provider value={{ 
        activeView, 
        viewport, 
        showNotification,
        theme: 'light',
        user: null
      }}>
        <div className="relative">
          <Suspense fallback={
            <div className="min-h-screen flex items-center justify-center bg-white">
              <Loader2 className="w-8 h-8 animate-spin text-black" />
              <span className="ml-2 text-black">Loading...</span>
            </div>
          }>
            {activeView === 'landing' && (
              <LandingPage 
                viewport={viewport} 
                setActiveView={setActiveView} 
                animationSpeed={animationSpeed} 
              />
            )}
            {activeView === 'demo' && (
              <DemoSelector 
                setActiveView={setActiveView} 
                animationSpeed={animationSpeed} 
              />
            )}
            {activeView === 'creator' && (
              <CreatorDashboard 
                animationSpeed={animationSpeed} 
              />
            )}
            {activeView === 'brand' && (
              <BrandDashboard 
                viewport={viewport} 
                animationSpeed={animationSpeed} 
              />
            )}
          </Suspense>
        </div>
      </QettaContext.Provider>
    </ErrorBoundary>
  );
};

export default QettaPlatform;
